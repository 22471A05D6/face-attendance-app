package com.example.attendance

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var b:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        b=findViewById(R.id.imp)
        b.setOnClickListener{
            val i= Intent(this, SecondActivity::class.java)
            startActivity(i)
        }


    }
}
package com.example.attendance

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText

class ThirdActivity : AppCompatActivity() {
    lateinit var button: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        button=findViewById(R.id.registrationBtn)
       button.setOnClickListener {
           val i= Intent(this, FourthActivity::class.java)
           startActivity(i)
       }



    }
}
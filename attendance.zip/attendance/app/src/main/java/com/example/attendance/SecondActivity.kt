package com.example.attendance

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class SecondActivity : AppCompatActivity() {
    lateinit var b1:Button
    lateinit var b2:Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        b1=findViewById(R.id.but1)
        b2=findViewById(R.id.but2)



        b2.setOnClickListener {
            val i= Intent(this, FifthActivity::class.java)

            startActivity(i)
        }
        b1.setOnClickListener {
            val i= Intent(this, ThirdActivity::class.java)

            startActivity(i)
        }

    }
}